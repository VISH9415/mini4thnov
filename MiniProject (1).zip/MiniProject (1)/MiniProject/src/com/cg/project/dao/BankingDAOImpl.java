package com.cg.project.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.project.bean.AccountBean;
import com.cg.project.bean.CustomerBean;
import com.cg.project.bean.PayeeBean;
import com.cg.project.bean.ServiceTrackerBean;
import com.cg.project.bean.TransactionsBean;
import com.cg.project.bean.UserBean;
import com.cg.project.exception.BankingException;
import com.cg.project.util.DBUtil;

public class BankingDAOImpl implements IBankingDAO{

	private static Logger logger = Logger.getLogger(com.cg.project.dao.BankingDAOImpl.class);
	//open account 
	@Override
	public AccountBean fetchAccounts(long actId) throws BankingException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		AccountBean accountBean = new AccountBean();
		try{
			conn = DBUtil.createConnection();
			String sql = "Select * from accountmaster where account_Id="+actId;
			pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			//int count = 0;
			while(rs.next()) {
				accountBean.setAccountId(rs.getLong(1));
				accountBean.setAccountType(rs.getString(2));
				accountBean.setAccountBalance(rs.getDouble(3));
				accountBean.setOpenDate(rs.getDate(4));
			}
			logger.info("");
		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}
		return accountBean;
	}
	//show balance
	@Override  
	public double fetchAmount(long actId) throws BankingException
	{
		int amt = 0;
		Connection conn = null;
		PreparedStatement pst = null;
		try{
			conn = DBUtil.createConnection();
			String sql = "Select ACCOUNT_BALANCE from accountmaster where account_Id="+actId;
			pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				amt= rs.getInt(1);
			}
			logger.info("");
		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}
		return amt;
	}

	@Override
	public long openAccount(CustomerBean customerBean) throws BankingException
	{
		int count = 0;
		long acId=0;
		Connection conn =null;
		PreparedStatement pst= null;
		String sql = new String("INSERT INTO customer VALUES(acc_seq.nextval,?,?,?,?,?)");
		try{
			conn = DBUtil.createConnection();
			//	System.out.println("***********************"+connStudent);
			pst = conn.prepareStatement(sql);
			//pst.setLong(1,customerBean.getAccountId());
			pst.setString(1,customerBean.getCustomerName());
			pst.setString(2,customerBean.getEmail());
			pst.setString(3,customerBean.getAddress());
			pst.setString(4,customerBean.getPancard());
			pst.setString(5,customerBean.getAccountType());

			//pstStudent.setString(6,bookingBean.getDateOfTransport());
			count = pst.executeUpdate();

			conn = null;
			pst = null;
			conn = DBUtil.createConnection();
			sql = "Select account_id from customer";
			pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();

			while(rs.next()) {
				acId = rs.getLong(1);
			}
			customerBean.setAccountId(acId);
			logger.info("");

		}
		catch(SQLException se)
		{
			logger.error("");
			throw new BankingException("");
		}
		finally{
			try{
				DBUtil.closeConnection();
			}catch(SQLException se){
				
				throw new BankingException("Problems in closing connection");
			}
			System.out.println(count+" customer results affected");
			System.out.println("accountId is: "+acId);
		}
		return acId;
	}

	@Override
	public CustomerBean validateId(long actId) throws BankingException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		CustomerBean customerBean = new CustomerBean();
		try{
			conn = DBUtil.createConnection();
			String sql = "Select * from customer where account_Id="+actId;
			pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				customerBean.setAccountId(rs.getLong(1));
				customerBean.setCustomerName(rs.getString(2));
				customerBean.setEmail(rs.getString(3));
				customerBean.setAddress(rs.getString(4));
				customerBean.setPancard(rs.getString(5));
				customerBean.setAccountType(rs.getString(6));
			}
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}
		return customerBean;
	}

	/*	public int validateAccountByUserId(long userId) throws SQLException
	{
		Connection conn = null;
		PreparedStatement pst = null;

		conn = DBUtil.createConnection();
		String sql = "Select  from  where account_Id="
		pst = conn.prepareStatement(sql);
		ResultSet rs = pst.executeQuery();
		int count = 0;
		while(rs.next()) {
			count = rs.getInt(1);
		}
		return count;
	}*/

	@Override
	public String deposit(long actId,double amount,AccountBean accountBean) throws BankingException
	{
		String actType = "";
		Connection conn = null;
		PreparedStatement pst = null;
		try{
			conn = DBUtil.createConnection();
			// getting acct type for accountmaster table...
			String sql = "Select account_type from customer where account_Id="+actId;
			pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				actType = rs.getString(1);
			}
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}
		System.out.println("act type is: "+actType);
		pst=null; 
		conn = null;
		Date openDate=null;

		String sql1 = "INSERT INTO ACCOUNTMASTER (ACCOUNT_ID,ACCOUNT_TYPE,ACCOUNT_BALANCE) VALUES(?,?,?)";
		int count = 0;
		try{
			conn = DBUtil.createConnection();
			//	System.out.println("***********************"+connStudent);
			pst = conn.prepareStatement(sql1);
			pst.setLong(1,actId);
			pst.setString(2,actType);
			pst.setDouble(3,amount);
			//LocalDate date = LocalDate.now();
			//openDate = Date.valueOf(date);
			//pst.setDate(4,accountBean.getOpenDate());

			count = pst.executeUpdate();
			logger.info("");

		}catch(SQLException se)
		{
			logger.error("");
			System.out.println("unique constraint violated");
			throw new BankingException("Record not inserted: ");
		}
		finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se){
				throw new BankingException("Problems in closing connection");
			}
		}
		if(count==0) {
			System.out.println(count+" results inserted");}
		//String out = "amount+\" is deposited in \"+actId+\" on date \"+openDate";
		return("Deposited");
	}

	@Override
	public String depositUpdate(long actId,double amount) throws BankingException {
		Connection conn = null;
		PreparedStatement pst = null;
		//Date openDate=null;
		// NEED TO UPDATE DATE ALSO .. 

		String sql1 = "UPDATE ACCOUNTMASTER SET ACCOUNT_BALANCE = ACCOUNT_BALANCE + ? WHERE ACCOUNT_ID = ?";
		int count = 0;
		try
		{
			conn = DBUtil.createConnection();
			pst = conn.prepareStatement(sql1);
			pst.setDouble(1,amount);
			pst.setLong(2, actId);
			count = pst.executeUpdate();
			System.out.println(count);
			logger.info("deposited...");

		}catch(SQLException se)
		{
			logger.error("not deposited...");

			throw new BankingException("");
		}
		finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se){
				throw new BankingException("Problems in closing connection");
			}
		}
		if(count==0) {
			System.out.println(count+" results updated...");}
		return("Deposited"+amount);
	}

	@Override
	public void transactionUpdate(long accId,TransactionsBean transBean ) throws BankingException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		//	conn = DBUtil.createConnection();
		//double transAmt=0;
		//Date transDate=null;
		//first fetching account details on which transaction is done ...
		//String sql = "SELECT OPEN_DATE FROM ACCOUNTMASTER WHERE ACCOUNT_ID="+accId;
		//String sql = "INSERT INTO TRANSACTION_MASTER "
		//pst = conn.prepareStatement(sql);
		//ResultSet rs = pst.executeQuery();
		//TransactionsBean trans = new TransactionsBean();
		//while(rs.next()) {
		//transAmt = rs.getDouble(1);
		//transDate = rs.getDate(1);//keeping all dates as sysdate
		//}
		//	System.out.println("account details obtained...");
		// insert transaction record...
		String sql1 = "INSERT INTO TRANSACTIONS VALUES(tran_seq.nextval,?,?,?,?,?)";
		int count = 0;
		try{
			conn = DBUtil.createConnection();
			//	System.out.println("***********************"+connStudent);
			pst = conn.prepareStatement(sql1);
			pst.setString(1,transBean.getTransDescription());
			LocalDate tdate = LocalDate.now();
			Date trdate = Date.valueOf(tdate);
			pst.setDate(2,trdate);
			pst.setString(3,transBean.getTransactionType());
			pst.setDouble(4,transBean.getTransactionAmount());
			pst.setLong(5,accId);
			count = pst.executeUpdate();
			logger.info("");

		}catch(SQLException se)
		{
			logger.error("");
			throw new BankingException("Record not inserted: ");
		}
		finally
		{
			try{
				DBUtil.closeConnection();
			}catch(SQLException se){
				logger.error("");
				throw new BankingException("Problems in closing connection");
			}
		}
		System.out.println(count+" trans results inserted");
	}

	@Override
	public String withdraw(long accId,double amount) throws BankingException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		//Date openDate=null;
		// NEED TO UPDATE DATE ALSO .. 

		String sql1 = "UPDATE ACCOUNTMASTER SET ACCOUNT_BALANCE = ACCOUNT_BALANCE-? WHERE ACCOUNT_ID = ?";
		int count = 0;
		try{
			conn = DBUtil.createConnection();
			pst = conn.prepareStatement(sql1);
			pst.setDouble(1,amount);
			pst.setLong(2, accId);
			count = pst.executeUpdate();
			System.out.println(count);
			logger.info("");

		}catch(SQLException se)
		{
			logger.error("");
			throw new BankingException("");

		}finally{
			try{
				DBUtil.closeConnection();
			}catch(SQLException se){
				logger.error("");
				throw new BankingException("Problems in closing connection");
			}
		}

		if(count==0) {
			System.out.println(count+" results updated...");}
		return(""+amount+" is withdrawn");	
	}

	@Override
	public void sendfund(double amt, long actId, long pactId) throws BankingException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		String sql1 = "UPDATE ACCOUNTMASTER SET ACCOUNT_BALANCE = ACCOUNT_BALANCE-? WHERE ACCOUNT_ID = ?";
		int count = 0;
		try{
			conn = DBUtil.createConnection();
			pst = conn.prepareStatement(sql1);
			pst.setDouble(1,amt);
			pst.setLong(2, actId);
			count = pst.executeUpdate();
			System.out.println(count+" account updated...");
			//conn.close();
			//fetch records for pactId...for actid it has to be there ...
			count = 0;

			String sql = "SELECT COUNT(*) FROM ACCOUNTMASTER WHERE ACCOUNT_ID=?";
			conn = DBUtil.createConnection();
			pst = conn.prepareStatement(sql);
			pst.setLong(1, pactId);
			ResultSet rs = pst.executeQuery();

			while(rs.next()){
				count = rs.getInt(1);
			}

			//conn.close();

			if(count!=0)
			{//records are there in accountmaster for pactId...
				//count = 0;
				sql = null;
				sql = "UPDATE ACCOUNTMASTER SET ACCOUNT_BALANCE = ACCOUNT_BALANCE+? WHERE ACCOUNT_ID = ?";
				//conn =  DBUtil.createConnection();
				pst = conn.prepareStatement(sql);
				pst.setDouble(1,amt);
				pst.setLong(2, pactId);
				count = pst.executeUpdate();
				//conn.close();
				System.out.println(count+"account updated...");
			}
			else
			{  //select account type of pactId during open account.... first (needed) 
				sql=null;
				sql = "SELECT ACCOUNT_TYPE FROM CUSTOMER WHERE ACCOUNT_ID=?";
				//PreparedStatement pst1 = null;
				pst.close();
				pst = conn.prepareStatement(sql);
				pst.setLong(1, pactId);
				rs = pst.executeQuery();
				String actType = null;
				while(rs.next()){
					actType = rs.getString(1);
				}
				System.out.println("account type is: "+actType);

				String sql2 = "INSERT INTO ACCOUNTMASTER VALUES(?,?,?,?)";
				pst.close();
				pst = conn.prepareStatement(sql2);
				pst.setLong(1,pactId);
				pst.setString(2,actType);
				pst.setDouble(3,amt);
				LocalDate tdate = LocalDate.now();
				Date trdate = Date.valueOf(tdate);
				pst.setDate(4,trdate);
				count = pst.executeUpdate();
				System.out.println(count+"account inserted...");

			}

			//insert in fund transfer
			pst = null;
			int temp=0;
			sql = "INSERT INTO FUND_TRANSFER VALUES(fund_seq.nextval,?,?,?,?)";
			//conn = DBUtil.createConnection();
			//	System.out.println("***********************"+connStudent);
			pst = conn.prepareStatement(sql);
			pst.setLong(1,actId);
			pst.setLong(2,pactId);
			//pst.setDouble(3,amount);
			LocalDate date = LocalDate.now();
			Date openDate = Date.valueOf(date);
			pst.setDate(3,openDate);
			pst.setDouble(4,amt);
			temp = pst.executeUpdate();
			System.out.println(temp+"fund record inserted...");
			logger.info("");

		}catch(SQLException se)
		{
			logger.error("");
			throw new BankingException("");
		}
		finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se){
				logger.error("");
				throw new BankingException("Problems in closing connection");
			}
		}
	}
	
	@Override
	public String validatePassword(String uId) throws BankingException{
		Connection conn = null;
		String pwd=null;
		PreparedStatement pst = null;
		try{
			conn = DBUtil.createConnection();
			String sql = "Select login_password from usertable where user_id=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, uId);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				pwd = rs.getString(1);
			}
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}	
		return pwd;
	}

	@Override
	public int registerUser(UserBean userBean) throws BankingException
	{
		//new user ...
		Connection conn=null;
		PreparedStatement pst = null;
		int status = 0;
		String sql = "INSERT INTO USERTABLE VALUES(?,?,?,?,?)";
		//pst.close();
		try {
			conn = DBUtil.createConnection();
			pst = conn.prepareStatement(sql);
			pst.setLong(1,userBean.getAccountId());
			pst.setString(2,userBean.getUserId());
			pst.setString(3,userBean.getLoginPassword());
			pst.setString(4,userBean.getTransactionPassword());
			pst.setString(5,"nope");
			status = pst.executeUpdate();
			
			logger.info("");
			
		} catch (SQLException e) {
			logger.error("");
			e.printStackTrace();
			//throw new BankingException("");
		}
		//System.out.println(status +" user registered...");
		return status;
		
	}

	@Override
	public HashMap<String,UserBean> fetchUserById(String uid) throws BankingException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		HashMap<String,UserBean> userMap = new HashMap<String,UserBean>();
		UserBean userBean = new UserBean();
		try{
			conn = DBUtil.createConnection();
			String sql1 = "Select * from usertable where user_id=?";
			pst = conn.prepareStatement(sql1);
			pst.setString(1, uid);
			ResultSet rs1 = pst.executeQuery();
			while(rs1.next()){
				userBean.setAccountId(rs1.getLong(1));
				userBean.setUserId(rs1.getString(2));
				userBean.setLoginPassword(rs1.getString(3));
				userBean.setTransactionPassword(rs1.getString(4));
				userBean.setLockStatus(rs1.getString(5));
				
			}
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}	
		userMap.put(uid,userBean);
		return userMap;	
	}
	
	//updating address and password based on request..
	@Override
	public int updateUserDetails(UserBean userBean,String uid,long actId) throws BankingException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		int count=0;
		try{
			conn = DBUtil.createConnection();
			String sql = "UPDATE USERTABLE SET ACCOUNT_ID=?,LOGIN_PASSWORD=? WHERE USER_ID=?";
			pst = conn.prepareStatement(sql);
			pst.setLong(1,actId);
			pst.setString(2,userBean.getLoginPassword());
			pst.setString(3,uid);
			count = pst.executeUpdate();
			//conn.close();
			System.out.println(count+" user updated...");
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}	
		return count;	
	}

	@Override
	public int fetchUserByActId(long acid) throws BankingException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		int count=0; 
		try{
			conn = DBUtil.createConnection();
			String sql = "Select count(*) from usertable where account_id=?";
			pst = conn.prepareStatement(sql);
			pst.setLong(1, acid);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				count = rs.getInt(1);	
			}
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}	
		return count;	
	}

	@Override
	public int updateCustomerAddress(long actId,String address) throws BankingException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		int count=0;
		try{
			conn = DBUtil.createConnection();
			String sql = "UPDATE CUSTOMER SET ADDRESS=? WHERE ACCOUNT_ID=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1,address);
			pst.setLong(2,actId);
			count = pst.executeUpdate();
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}	
		return count;	
	} 

	@Override
	public HashMap<Long, List<TransactionsBean>> viewMiniStatement(long accId) throws BankingException
	{
		Date dateOfTrans = null;
		HashMap<Long, List<TransactionsBean>> miniMap = new HashMap<>();
		Connection conn = null;
		PreparedStatement pst = null;
		try{
			conn = DBUtil.createConnection();
			String sql = "select * from (select * from TRANSACTIONS order by DATE_OF_TRANSACTION desc) where rownum<=10 and account_no ="+accId;
			pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			List<TransactionsBean> list = new ArrayList<TransactionsBean>();
			while(rs.next()){
				TransactionsBean transactionsBean = new TransactionsBean(rs.getLong(1),rs.getString(2),rs.getDate(3),rs.getString(4),rs.getDouble(5),rs.getLong(6));
				list.add(transactionsBean);
			}
			miniMap.put(accId,list);
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}
		return miniMap;
	}

	@Override
	public HashMap<Long, List<TransactionsBean>> viewDetailedStatement(long accId,Date date1,Date date2) throws BankingException 
	{
		HashMap<Long, List<TransactionsBean>> detMap = new HashMap<>();
		Connection conn = null;
		PreparedStatement pst = null;
		try{
			conn = DBUtil.createConnection();
			String sql = "SELECT * FROM TRANSACTIONS WHERE ACCOUNT_NO=? AND DATE_OF_TRANSACTION BETWEEN ? AND ?";
			pst = conn.prepareStatement(sql);
			pst.setLong(1,accId);
			pst.setDate(2, date1);
			pst.setDate(3, date2);
			ResultSet rs = pst.executeQuery();
			List<TransactionsBean> list = new ArrayList<TransactionsBean>();
			while(rs.next()){
				TransactionsBean transactionsBean = new TransactionsBean(rs.getLong(1),rs.getString(2),rs.getDate(3),rs.getString(4),rs.getDouble(5),rs.getLong(6));
				list.add(transactionsBean);
			}
			detMap.put(accId,list);
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}
		return detMap;
	}
	
	@Override
	public int serviceTracking(ServiceTrackerBean service,long accId) throws BankingException
	{
		int status=0;
		Connection conn=null;
		PreparedStatement pst = null;
		String sql = "INSERT INTO SERVICETRACKER VALUES(SERV_SEQ.NEXTVAL,?,?,?,?)";
		try {
			conn = DBUtil.createConnection();
			pst = conn.prepareStatement(sql);
			pst.setString(1,service.getServiceDescription());
			pst.setLong(2,accId);
			pst.setDate(3,service.getServiceRaisedDate());
			pst.setString(4,service.getServiceStatus());
			status = pst.executeUpdate();
			logger.info("");

		} catch (SQLException e) {
			logger.error("");
			throw new BankingException("");
		}
		System.out.println(status +" Service registered...");
		return status;	
	}

	@Override
	public Date fetchOpenDate(long accId) throws BankingException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		Date opdate = null;
		try{
			conn = DBUtil.createConnection();
			String sql = "Select open_date from accountmaster where account_Id="+accId;
			pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				opdate = rs.getDate(1);
			}
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}
		return opdate;
	}
	
	@Override
	public int insertAccount(AccountBean account) throws BankingException {
		Connection conn = null;
		PreparedStatement pst = null;
		try{
			conn = DBUtil.createConnection();
			String sql2 = "INSERT INTO ACCOUNTMASTER VALUES(?,?,?,?)";
			int count = 0;
			pst = conn.prepareStatement(sql2);
			pst.setLong(1,account.getAccountId());
			pst.setString(2,account.getAccountType());
			pst.setDouble(3,account.getAccountBalance());
			pst.setDate(4,account.getOpenDate());
			count = pst.executeUpdate();
			logger.info("");

			System.out.println(count+"accounts inserted...");
			return count;
		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}
	}
	
	@Override
	public long getPreviousUser(String uId) throws BankingException
	{
		Connection conn = null;
		PreparedStatement pst = null;
		UserBean userBean = new UserBean();
		try{
			conn = DBUtil.createConnection();
			String sql = "Select account_id from usertable where USER_ID= ?";
			pst = conn.prepareStatement(sql);
			pst.setString(1,uId);
			ResultSet rs = pst.executeQuery();

			while(rs.next()) {
				userBean.setAccountId(rs.getLong(1));
			}
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}
		return userBean.getAccountId() ;
	}

	@Override
	public int insertService(ServiceTrackerBean serviceTracker) throws BankingException
	{
		int count = 0;
		Connection conn =null;
		PreparedStatement pst= null;
		String sql = new String("INSERT INTO SERVICETRACKER VALUES(serv_seq.nextval,?,?,?,?)");
		try{
			conn = DBUtil.createConnection();
			pst = conn.prepareStatement(sql);
			pst.setString(1,serviceTracker.getServiceDescription());
			pst.setLong(2,serviceTracker.getAccountId());
			pst.setDate(3,serviceTracker.getServiceRaisedDate());
			pst.setString(4,serviceTracker.getServiceStatus());
			count = pst.executeUpdate();
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("Record not inserted: ");
		}
		finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se){
				logger.error("");
				throw new BankingException("Problems in closing connection");
			}
			System.out.println(count+" service results affected");
		}
		return count;
	}
	@Override
	public int insertPayee(PayeeBean payeeBean) throws BankingException {
		int count = 0;
		Connection conn =null;
		PreparedStatement pst= null;
		String sql = new String("INSERT INTO PAYEETABLE VALUES(?,?,?)");
		try{
			conn = DBUtil.createConnection();
			pst = conn.prepareStatement(sql);
			pst.setLong(1,payeeBean.getAccountId());
			pst.setLong(2,payeeBean.getPayeeAccountId());
			pst.setString(3,payeeBean.getNickName());
			count = pst.executeUpdate();
			logger.info("");
		}catch(SQLException se){
			logger.error("");
			throw new BankingException("Record not inserted: ");
		}
		finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se){
				logger.error("");
				throw new BankingException("Problems in closing connection");
			}
			System.out.println(count+" Payee results affected");
		}
		return count;
	}
	@Override
	public List<UserBean> viewAccountHolders() throws BankingException {
		Connection conn = null;
		PreparedStatement pst = null;
		//UserBean userBean = new UserBean();
		List<UserBean> userList = new ArrayList<>();
		try{
			conn = DBUtil.createConnection();
			String sql = "Select * from usertable where account_id!=0";
			pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();

			while(rs.next()) {
			UserBean userBean = new UserBean(rs.getLong(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
			userList.add(userBean);
			}
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}
		
		return userList;
	}
	@Override
	public List<TransactionsBean> viewTransactionsDetails()	throws BankingException {
		Connection conn = null;
		PreparedStatement pst = null;
		//UserBean userBean = new UserBean();
		List<TransactionsBean> transList = new ArrayList<>();
		try{
			conn = DBUtil.createConnection();
			String sql = "Select * from transactions";
			pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();

			while(rs.next()) {
			TransactionsBean transactionsBean= new TransactionsBean(rs.getLong(1),rs.getString(2),rs.getDate(3),rs.getString(4),rs.getDouble(5),rs.getLong(6));
			transList.add(transactionsBean);
			}
			logger.info("");

		}catch(SQLException se){
			logger.error("");
			throw new BankingException("");
		}
		
		return transList;
	}
}