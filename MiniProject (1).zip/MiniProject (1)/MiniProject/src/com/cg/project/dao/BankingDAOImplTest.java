package com.cg.project.dao;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.project.bean.CustomerBean;
import com.cg.project.bean.UserBean;
import com.cg.project.exception.BankingException;

public class BankingDAOImplTest {

	private IBankingDAO dao = new BankingDAOImpl();
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
/*
	@Test
	public final void testRegisterUser() throws BankingException {
		UserBean userBean = new UserBean(45445L,"m","n","a","z","o");
		dao.registerUser(userBean);
	}*/

	@Test
	public final void testUpdateCustomerAddress() throws BankingException {
		CustomerBean customerBean = new CustomerBean();
		long actId = 457889L;
		String address = "a";
		dao.updateCustomerAddress(actId, address);
	}
	@Test
	public final void testViewMiniStatement() throws BankingException {
		long actId = 457889L;
		dao.viewMiniStatement(actId);
	}

}
